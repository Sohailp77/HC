<?php
include "./connect.php";

if(isset($_GET["id"])) {
    $id = $_GET["id"];

    // Retrieve the task details from the database
    $query = "SELECT * FROM periphery.to_do WHERE id = :id";
    $queryStmt = $pgconn->prepare($query);
    $queryStmt->bindParam(':id', $id, PDO::PARAM_INT);
    $queryStmt->execute();
    $task = $queryStmt->fetch(PDO::FETCH_ASSOC);
} else {
    // Redirect to the home page if the ID is not provided
    header('Location: home.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Task</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<body>
    <div class="container my-5">
        <h2>Edit Task</h2>
        <form action="edit.php" method="POST">
            <input type="hidden" name="id" value="<?php echo $task['id']; ?>">
            <div class="mb-3">
                <label for="title" class="form-label">Title</label>
                <input type="text" class="form-control" id="title" name="title" value="<?php echo $task['name1']; ?>">
            </div>
            <div class="mb-3">
                <label for="desc" class="form-label">Description</label>
                <textarea class="form-control" id="desc" name="desc"><?php echo $task['content']; ?></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Update Task</button>
        </form>
    </div>
</body>
</html>