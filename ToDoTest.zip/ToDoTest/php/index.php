<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Log IN</title>
    <style>
        .container{
        background-color: aliceblue;
        border-radius: 9px;
        padding: 50px;
        margin-top: 100px;
        text-align: center;
        width: 30%;
        margin:50px;
        }

    </style>
</head>
<body>
    <div class="container">
        <h3>Log In</h3>
    <form action="login.php" method="POST">
        <input type="text" placeholder="User name" name="uname"></input><br>
        <input type="password" placeholder="Password" name="pass"></input><br>
        <button type="submit">Log In</button>
        </div>
    </form>
    
</body>
</html>