<?php
include "./connect.php";

  if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $sql = "DELETE FROM periphery.todo_list WHERE id = :id";
    $queryStmt = $pgconn->prepare($sql);
    $queryStmt->bindParam(':id', $id);
  
    try {
      $queryStmt->execute();
      echo "Row deleted successfully!";
      header('Location:admin.php');
    } catch (PDOException $e) {
      echo "Error deleting row: " . $e->getMessage();
    }
  }

?>