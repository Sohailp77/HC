 <?php

 session_start();
 include "./connect.php";
 
$user_name=$_POST['uname'];
$password=$_POST['pass']; 


 try{

 $query = "SELECT * FROM periphery.test WHERE user_name = :user_name1 AND Pass=:pass1"; //user_name1 and pass1 are dummy value we created that are then later binded with user inputed value  
  // user_name=:user_name1 this check if inputed value is equal to database value that already present in database 
 $queryStmt = $pgconn->prepare($query);     
 $queryStmt->bindParam(':user_name1', $user_name);
 $queryStmt->bindParam(':pass1', $password);   
 //$queryStmt->execute(':user_name1'=>$user_name,':pass1'=>$password); this also does the same thing
 $queryStmt->execute();
 $tasks = $queryStmt->fetch();
 
if($tasks){
    echo"Logged In";
    $_SESSION['name'] = $user_name;
    header('Location:home.php');
    
 }
else {
    echo "Incorrect username or password";
    //header('Location: index.php');
    exit();
}
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
?>