<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Details</title>
</head>
<body>
    <div class="container">
    <?php
include "./connect.php";

if(isset($_GET['id'])){  //get gets the id from url on click of button the id is passed on to details.php with id="" in url

$id=($_GET['id']);
$sql="SELECT * FROM periphery.todo_list WHERE id=:id";
$queryStmt = $pgconn->prepare($sql);
$queryStmt->bindParam(':id', $id);

try{

$queryStmt->execute();
$row=$queryStmt->fetch();
//print_r($row);
} catch (PDOException $e) {
    echo "Error fetching data: " . $e->getMessage();
}
}
?>
        <br></br>
        <labael><?php echo $row['task'];  ?></label>
        <labael><?php echo $row['description1'];  ?></label>
        <labael><?php echo $row['weekly'];  ?></label>
        <labael><?php //print_r($row);  ?></label>
    </div>
</body>
</html>


