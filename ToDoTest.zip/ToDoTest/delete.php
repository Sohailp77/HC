<?php
$dbname_p = 'hcbgoa';
$db_host_p = 'localhost';
$db_user_p = "postgres";
$db_password_p = "postgres";

try {
  $pgconn = new PDO("pgsql:host=$db_host_p;dbname=$dbname_p", $db_user_p, $db_password_p, array(PDO::ATTR_PERSISTENT => true));
} catch (PDOException $e) {
  echo "Connection Failed: " . $e->getMessage();
  exit();
}

if (isset($_GET['id'])) {
  $id = $_GET['id'];
  $sql = "DELETE FROM periphery.to_do WHERE id = :id";
  $queryStmt = $pgconn->prepare($sql);
  $queryStmt->bindParam(':id', $id);

  try {
    $queryStmt->execute();
    echo "Row deleted successfully!";
    header('Location:home.php');
  } catch (PDOException $e) {
    echo "Error deleting row: " . $e->getMessage();
  }
}
?>