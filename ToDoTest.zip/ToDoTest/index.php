<?php
include "connect.php";


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<h2>List of Tasks</h2>
    <div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4">
        <?php foreach ($rows as $row) { ?>
            <div class="col">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo $row['name1']; ?></h5>
                        <p class="card-text"><?php echo $row['Date']; ?></p>
                        <p class="card-text"><?php echo $row['content']; ?></p>
                        <!-- <div class="d-flex justify-content-between">
                            <a href="./edit.php?id=<?php echo $row['id']; ?>" class="btn btn-primary">Edit</a>
                            <a href="./delete.php?id=<?php echo $row['id']; ?>" class="btn btn-danger">Delete</a>
                        </div> -->
                    </div>
                </div>
            </div>
        <?php } ?>
    </div>
</div>
</body>
</html>