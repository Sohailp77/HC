<?php
include "./connect.php";

$sql_s = "SELECT * FROM periphery.todo_list"; //Query
                  
$sql_s = $pgconn->prepare($sql_s); //connecting to database
$pgconn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); //pdo of connection
$sql_s->execute(); //to execute the query
$rows = $sql_s->fetchAll(); //if multiple variables use fetchall and foreach loop or while loop || if its fetch() no loop
  

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <style>
            .task-table {
        width: 100%;
        border-collapse: collapse;
    }

    .task-table th,
    .task-table td {
        padding: 10px;
        text-align: left;
        border: 1px solid #ccc;
    }

    .task-table th {
        background-color: #f2f2f2;
    }
    </style>

</head>
<body>
 <table class="task-table">
            <thead>
                <tr>
                    <th scope="col">Task</th>
                    <th scope="col">Description</th>
                    <th scope="col">Action</th>
                </tr>
            </thead>
            <?php
    foreach($rows as $row){?>
            <tbody>
            <tr >
                        <td><?php echo $row['task'];?></td>
                        <td><?php echo $row['description1'];?></td>
                        <td><a class="btn btn-primary" href="./delete.php?id=<?php echo $row['id']; ?>" role="button">Delete</a></td>
                    </tr>
    </tbody>
   <?php }?>
    </table>
</body>
</html>