<?php
include "./connect.php";
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Task List</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: Arial, sans-serif;
        }

        .container {
            margin-top: 50px;
        }

        .task-table {
            width: 100%;
            border-collapse: collapse;
        }

        .task-table th,
        .task-table td {
            padding: 8px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        .task-table th {
            background-color: #f2f2f2;
            font-weight: bold;
        }

        .task-table tr:hover {
            background-color: #f5f5f5;
        }
        .high-priority {
        color: red;
        }

        .medium-priority {
        color: orange;
        }

        .low-priority {
        color: green;
        }
    </style>
</head>

<body>
    <div class="container text-center">
        <h2>List of Tasks</h2>
    </div>
    <div class="container">
        <table class="task-table">
            <thead>
                <tr>
                    <th scope="col">Id</th>
                    <th scope="col">Date</th>
                    <th scope="col">Name</th>
                    <th scope="col">Task</th>
                    <th scope="col">Priority</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                  $sql_s = "SELECT * FROM periphery.to_do"; //Query
                  
                  $sql_s = $pgconn->prepare($sql_s); //connecting to database
                  $pgconn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); //pdo of connection
                  $sql_s->execute(); //to execute the query
                  $rows = $sql_s->fetchAll(); //if multiple variables use fetchall and foreach loop or while loop || if its fetch() no loop
                ?>
                <?php for($i=0;$i<count($rows);$i++){ ?>
                    <tr id="row">
                        <td><?php echo $i+1;?></td>
                        <td><?php echo $rows[$i]['Date'];?></td>
                        <td><?php echo $rows[$i]['name1'];?></td>
                        <td><?php echo $rows[$i]['content'];?></td>
                        <td><?php echo $rows[$i]['priority'];?></td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
    <script>
        setTimeout(function() {
            location.reload();
        }, 2000); // Reload the page every 2 seconds (2000 milliseconds)

        const prioritySelect = document.getElementById('Priority');
        const row = document.getElementById('row');

        prioritySelect.addEventListener('change', function () {
            row.className = ''; // Reset the class name

            // Set the class name based on the selected priority
            if (this.value === 'High') {
                row.classList.add('high-priority');
            } else if (this.value === 'Medium') {
                row.classList.add('medium-priority');
            } else if (this.value === 'Low') {
                row.classList.add('low-priority');
            }
        });
    </script>
</body>

</html>
