<?php
include "./connect.php";

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ToDo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <style>
  body {
    background-color: rgb(65, 138, 233);
  }

  .container {
    background-color: aliceblue;
    border-radius: 9px;
    padding: 20px;
    margin-top: 30px;
  }

  .my-2 {
    margin-bottom: 20px;
  }

  .my-5 {
    margin-top: 50px;
  }

  .mx-5 {
    margin-right: 50px;
    margin-left: 50px;
  }

  .btn-primary {
    margin-right: 5px;
  }

  .table {
    background-color: white;
  }

  .table th,
  .table td {
    vertical-align: middle;
  }

  .btn {
    margin-right: 5px;
  }

  .btn-primary {
    background-color: #007bff;
    border-color: #007bff;
  }

  .btn-primary:hover {
    background-color: #0069d9;
    border-color: #0062cc;
  }

  .btn-danger {
    background-color: #dc3545;
    border-color: #dc3545;
  }

  .btn-danger:hover {
    background-color: #c82333;
    border-color: #bd2130;
  }
</style>
</head>
<body>
    <div class=" text-center my-2 ">
        <h2>List of Tasks</h2>
        <a class="btn btn-primary" href="./Create.php" role="button">Add new Tasks</a>
    </div>
    <div class="container2 my-5 mx-5">
        <table class="table table-hover">
            <thead>
                <tr>
                    <th scope="col">Id</th>
                    <th scope="col">Name</th>
                    <th scope="col">Date</th>
                    <th scope="col">Content</th> 
                    <th scope="col">Priority</th>
                    <th scope="col">Action</th>
                </tr>
                </thead>
                <tbody>
                <?php 
                  $sql_s = "SELECT * FROM periphery.to_do"; //Query
                  
                  $sql_s = $pgconn->prepare($sql_s); //connecting to database
                  $pgconn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); //pdo of connection
                  $sql_s->execute(); //to execute the query
                  $rows = $sql_s->fetchAll(); //if multiple variables use fetchall and foreach loop or while loop || if its fetch() no loop
                    
                  //print_r($rows);
            ?>
                    <?php for($i=0;$i<count($rows);$i++){ ?>

                        <tr>
                        <td><?php echo $i+1;?></td>
                        <td><?php echo $rows[$i]['name1'];?></td>
                        <td><?php echo $rows[$i]['Date'];?></td>
                        <td><?php echo $rows[$i]['content'];?></td>
                        <td><?php echo $rows[$i]['priority'];?></td>
                        <td>
                            <form action="delete.php" method="post">
                            <a class="btn btn-primary" href="./delete.php?id=<?php echo $rows[$i]['id']; ?>" type="submit">Delete</a>
                             <!-- <a  class="btn btn-primary" href="./edit.php?id=<?php //echo $row[$i]['id']; ?>">Edit</a> -->
                             <?php
                             echo $row[$i]['id'];
                             ?>
                            </form>
                        </td>
                        </tr>



                    <?php } ?>
            </tbody>
        </table>
        <div class="container text-center my-2 ">
    <h2>List of Tasks</h2>
    <div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4">
        <?php foreach ($rows as $row) { ?>
            <div class="col">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo $row['name1']; ?></h5>
                        <p class="card-text"><?php echo $row['Date']; ?></p>
                        <p class="card-text"><?php echo $row['content']; ?></p>
                        <div class="d-flex justify-content-between">
                            <a href="./edit.php?id=<?php echo $row['id']; ?>" class="btn btn-primary">Edit</a>
                            <a href="./delete.php?id=<?php echo $row['id']; ?>" class="btn btn-danger">Delete</a>
                        </div>
                    </div>
                </div>
            </div>
        <?php } ?>
    </div>
</div>       
</div>
</body>
</html>
