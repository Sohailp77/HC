<?php
include "./connect.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $Title = $_POST['title'];
    $Desc = $_POST['desc'];

    if (!empty($Title) && !empty($Desc)) {
        // Perform the database insertion here
    } else {
        echo "Title and Description are required.";
    }

    $query = "INSERT INTO periphery.to_do(name1,content) VALUES(:title1, :desc1)";
    $queryStmt = $pgconn->prepare($query);
    $pgconn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); //pdo of connection
    $executeSuccess = $queryStmt->execute(array(':title1'=>$Title,':desc1'=>$Desc)); //to execute the query

    if($executeSuccess){
        header('Location:home.php');
    }

}
    
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h3 style=>Task Added</h3>
    <br></br>
    <a class="btn btn-primary" href="./home.php" role="button">Back</a></div>
</body>
</html>