<?php
include "./connect.php";

if(isset['details']){
    $sql="SELECT * FROM periphery.todo_list WHERE id=$Id_To_Details";
$queryStmt = $pgconn->prepare($sql);
$queryStmt->bindParam(':Id_To_Details', $id);
try{

$queryStmt->execute();
$row=$queryStmt->fetch();
print_r($row);
} catch (PDOException $e) {
    echo "Error fetching data: " . $e->getMessage();
}
}


?>