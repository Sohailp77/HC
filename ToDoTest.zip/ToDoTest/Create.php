<?php
include "./connect.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $Title = $_POST['title'];
    $Desc = $_POST['desc'];
    $Priority=$_POST['priority'];

    if (!empty($Title) && !empty($Desc)) {
        // Perform the database insertion here
        
    $query = "INSERT INTO periphery.to_do(name1,content,priority) VALUES(:title1, :desc1, :priority)";
    $queryStmt = $pgconn->prepare($query);
    $pgconn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); //pdo of connection
    $executeSuccess = $queryStmt->execute(array(':title1'=>$Title,':desc1'=>$Desc, 'priority'=>$Priority)); //querystmt=to execute the query   executeSuccess=to take the page on home page also to prevent empty values from submitting to db

     if($executeSuccess){
         header('Location:home.php');
    } else {
        echo "Title and Description are required.";
    }

    // $query = "INSERT INTO periphery.to_do(name1,content) VALUES(:title1, :desc1)";
    // $queryStmt = $pgconn->prepare($query);
    // $pgconn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); //pdo of connection
    // $executeSuccess = $queryStmt->execute(array(':title1'=>$Title,':desc1'=>$Desc)); //querystmt=to execute the query   executeSuccess=to take the page on home page also to prevent empty values from submitting to db

    //  if($executeSuccess){
    //      header('Location:home.php');
    }

}
    
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<style>
    /* body{
    background-color: rgb(65, 138, 233);
    } */
    .container {
        background-color: aliceblue;
        border-radius: 9px;
        padding: 50px;
        margin-top: 100px;
        text-align: center;
        width: 30%;
    }
/* .container input{
    width: 50%;
    margin: 20px 140px;
    border-radius: 9px;
    text-align: center;
    padding: 4px;
} */
/* .container textarea{
    border-radius: 9px;
    align-self: center;
    text-align: center;
} */

        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }

        h1 {
            text-align: center;
        }

        .container {
            max-width: 400px;
            margin: 10 auto;
        }

        form {
            background-color: #f5f5f5;
            padding: 20px;
            border-radius: 5px;
        }

        input[type="text"],
        textarea,
        select {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

    
</style>
</head>
<body>
    <div class="container">
        <h2 style="text-align: center;">Task Details</h2>
        <form class="row" action="Create.php" method="post">
            <input id="title" name="title"placeholder="Title" ></input>
            <textarea id="desc" name="desc"placeholder="Title Discription"></textarea>
            
            <div> 
            
            <label>Select priority:</label>
                <select name="priority" id="priority">
                <option value="High">High<option>
                <option value="Medium">Medium<option>
                <option value="Low">Low<option>
            </select></div>
            <div class="container2 my-3">
                <button class="btn btn-primary" type="submit" role="button">Add</button>
                <a class="btn btn-primary" href="./home.php" role="button">Cancel</a></div>
        </form>
    </div>
    <script>
       
    </script>   
</body>
</html>