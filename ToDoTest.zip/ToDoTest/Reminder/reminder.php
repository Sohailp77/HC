<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
include "./connect.php";
$currentDayOfWeek = date('N');
$currentDayOfMonth = date('j');
$currentDayOfMonth = 1;
// $currentDayOfWeek=2;

try {
    $query = "SELECT task, description1,id FROM periphery.todo_list WHERE frequency = :currentDayOfWeek";
    $queryStmt = $pgconn->prepare($query);
    $queryStmt->bindParam(':currentDayOfWeek', $currentDayOfWeek);
    $queryStmt->execute();
    $tasks = $queryStmt->fetchAll();
} catch (PDOException $e) {
    echo "Error fetching data: " . $e->getMessage();
}

try {
    $query2 = "SELECT task, description1 FROM periphery.todo_list WHERE monthly1 = :currentDayOfMonth";
    $queryStmt2 = $pgconn->prepare($query2);
    $queryStmt2->bindParam(':currentDayOfMonth', $currentDayOfMonth);
    $queryStmt2->execute();
    $tasks2 = $queryStmt2->fetchAll();
} catch (PDOException $e) {
    echo "Error fetching data: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Reminders</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }

        h1 {
            text-align: center;
        }

        .container {
            max-width: 600px;
            margin: 0 auto;
        }

        .task-box {
            background-color: #fff;
            border: 1px solid #ccc;
            padding: 10px;
            margin-bottom: 20px;
            border-radius: 10px;
            
        }
        
        .task-card {
            background-color: #f5f5f5;
            border: 1px solid #ccc;
            border-radius: 5px;
            padding: 10px;
            margin-bottom: 10px; 
            transition: background-color 0.3s ease;
        }
        .task-card h3 {
            margin-top: 0;
        }

        .task-card p {
            margin-bottom: 0;
        }
        .task-card:hover {
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
        }

        h2 {
            margin-top: 20px;
        }

        ul {
            list-style: none;
            padding: 0;
        }

        li {
            margin-bottom: 10px;
        }

        strong {
            font-weight: bold;
        }
    </style>
</head>
<body>
    <h1>Reminders</h1>
    <div class="container" >
        <h2>Todays Tasks</h2>
        <?php if (!empty($tasks)) { ?>
            <div class="task-box">
                <?php foreach($tasks as $task){ ?>
                    <div class="task-card" >
                        <h3>Task: <?php echo $task['task']; ?></h3>
                        <p>Description: <?php echo $task['description1']; ?></p>
                        <button  onclick="changeColor(this)">Done</button>
                        <a class="btn btn-primary" href="./details.php?id=<?php echo $task['id']; ?>">Details</a>
                        <form action="details2.php" method="POST">
                        <input type="hidden" name="Id_To_Details" value=<?php echo $task['id'];?>></input>
                        <input type="submit" name="details" value="Details" id="details"></input>
                        </form>
                    </div>
                <?php } ?>
            </div>
        <?php } else { ?>
            <p>No tasks for today.</p>
        <?php } ?>
        <a href="./add.php">back</a>

    <!-- display month reminders -->
    <?php if (!empty($tasks2)) { ?>
        <h2>Monthly Task</h2>
        <div class="task-box">
            <?php foreach($tasks2 as $task2){ ?>
                <div class="task-card">
                    <h3>Task: <?php echo $task2['task']; ?></h3>
                    <p>Description: <?php echo $task2['description1']; ?></p>
                    <button onclick="changeColor(this)">Done</button>
                </div>
            <?php } ?>
        </div>
    <?php } ?>


    </div>



    <script>
    function changeColor(button) {
        var taskCard = button.parentElement;
        taskCard.style.backgroundColor = "#c3e6cb";
    }
</script>



</body>
</html>
