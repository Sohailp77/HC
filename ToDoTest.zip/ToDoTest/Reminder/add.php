<?php
include "./connect.php";
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (isset($_POST['submit'])) {
    $Task = $_POST['task'];
    $Tdesc = $_POST['tdesc1'];
    $Frequency = $_POST['frequency'];
    $Monthly=$_POST['monthly']; // name,id of input tag

    $query = "INSERT INTO periphery.todo_list (task, description1, frequency , monthly1) VALUES (:task1, :desc1, :frequency1 , :monthly)";
    //$query = "INSERT INTO periphery.todo_list (task, description1, frequency , monthly1)->these are column names of database VALUES (:task1, :desc1, :frequency1 , :monthly)->temprory values we declared";
    $queryStmt = $pgconn->prepare($query);
    $queryStmt->execute(array(':task1' => $Task, ':desc1' => $Tdesc, ':frequency1' => $Frequency, ':monthly'=>$Monthly));

    // Display success message or perform any other necessary actions
    echo "Task added successfully!";
    header('location:reminder.php');
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Recursive To-Do List</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }

        h1 {
            text-align: center;
        }

        .container {
            max-width: 400px;
            margin: 0 auto;
        }

        form {
            background-color: #f5f5f5;
            padding: 20px;
            border-radius: 5px;
        }

        input[type="text"],
        textarea,
        select {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <h1>Set Reminder</h1>
    <div class="container">
        <form action="add.php" method="post">
            <input type="text" name="task" id="task1" placeholder="Enter a task" required/>
            <textarea id="tdesc1" name="tdesc1" placeholder="Task description" required></textarea>
            <select name="frequency" id="frequency1">
                <option value="0">weekly</option>
                <option value="1">Every Monday</option>
                <option value="2">Every Tuesday</option>
                <option value="3">Every Wednesday</option>
                <option value="4">Every Thursday</option>
                <option value="5">Every Friday</option>
                <option value="6">Every Saturday</option>
                <option value="7">Every Sunday</option>
            </select>
            <select name="monthly" id=monthly> 
                <option value='0'>Monthly</option>
                <option value='1'>1st of Every Month</option>
                <option value='15'>15th of Every Month</option>
                <option value='19'>19th of Every Month</option>
            </select>
            <input type="submit" name="submit" value="Add Task" />
        </form>
    </div>
</body>
</html>
